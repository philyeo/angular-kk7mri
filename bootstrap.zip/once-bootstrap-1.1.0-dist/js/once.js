$(document).ready(function(){
  // layout components
  onceBackToTop();
  onceCollapse();
  onceTabsNavigation();
  onceTooltip();

  // form elements
  onceCreatePassword();
  onceDatePicker();
  onceNumeric();
  onceSelectPicker();
  onceSearchbox();

  // examples for ONCE site
  if($('#datetimepicker-1').length > 0){
    $('#datetimepicker-1').datetimepicker({
      locale: 'en',
      format: 'L',
      icons: {
        up: "icon icon-arrow-up",
        down: "icon icon-arrow-down",
        next: "icon icon-arrow-right",
        previous: "icon icon-arrow-left"
      }
    });
  }

  if($('#datetimepicker-2').length > 0){
    $('#datetimepicker-2').datetimepicker({
      locale: 'en',
      format: 'L',
      icons: {
        up: "icon icon-arrow-up",
        down: "icon icon-arrow-down",
        next: "icon icon-arrow-right",
        previous: "icon icon-arrow-left"
      }
    });

    $('#datetimepicker-3').datetimepicker({
      useCurrent: false,
      locale: 'en',
      format: 'L',
      icons: {
        up: "icon icon-arrow-up",
        down: "icon icon-arrow-down",
        next: "icon icon-arrow-right",
        previous: "icon icon-arrow-left"
      }
    });

    $("#datetimepicker-2").on("change.datetimepicker", function (e) {
      $('#datetimepicker-3').datetimepicker('minDate', e.date);
    });
    $("#datetimepicker-3").on("change.datetimepicker", function (e) {
      $('#datetimepicker-2').datetimepicker('maxDate', e.date);
    });
  }

  if($('#datetimepicker-4').length > 0){
    $('#datetimepicker-4').datetimepicker({
      locale: 'en',
      format: 'LT',
      icons: {
        up: "icon icon-arrow-up",
        down: "icon icon-arrow-down",
        next: "icon icon-arrow-right",
        previous: "icon icon-arrow-left"
      }
    });
  }

  if($('#datetimepicker-7').length > 0){
    $('#datetimepicker-7').datetimepicker({
      locale: 'en',
      format: 'L',
      icons: {
        up: "icon icon-arrow-up",
        down: "icon icon-arrow-down",
        next: "icon icon-arrow-right",
        previous: "icon icon-arrow-left"
      }
    });

    $('#datetimepicker-8').datetimepicker({
      useCurrent: false,
      locale: 'en',
      format: 'L',
      icons: {
        up: "icon icon-arrow-up",
        down: "icon icon-arrow-down",
        next: "icon icon-arrow-right",
        previous: "icon icon-arrow-left"
      }
    });

    $("#datetimepicker-7").on("change.datetimepicker", function (e) {
      $('#datetimepicker-8').datetimepicker('minDate', e.date);
    });
    $("#datetimepicker-8").on("change.datetimepicker", function (e) {
      $('#datetimepicker-7').datetimepicker('maxDate', e.date);
    });
  }

  if($("#ex6").length > 0){
    $("#ex6").slider();
    $("#ex6").on("slide", function(slideEvt){
      $("#ex6SliderVal").text(slideEvt.value);
    });
  }

  if($("#ex24").length > 0){
    $("#ex24").slider({
      tooltip: "always"
    });
  }
});

var onceTooltip = function(){
  $('[data-toggle="tooltip"]').tooltip();
}

var onceNumeric = function(){
  $('.input-numeric button').on('click', function(){
    let input = $(this).closest('.input-numeric').find('input[name=qty]');

    if($(this).data('action') === 'increment'){
      if(input.attr('max') === undefined || parseInt(input.val()) < parseInt(input.attr('max'))){
        input.val(parseInt(input.val(), 10) + 1);
      }
    } else if($(this).data('action') === 'decrement'){
      if(input.attr('min') === undefined || parseInt(input.val()) > parseInt(input.attr('min'))){
        input.val(parseInt(input.val(), 10) - 1);
      }
    }
  });
}

var onceBackToTop = function(){
  var duration = 200;
  $(window).scroll(function(){
    if ($(this).scrollTop() > 100){
      $('.back-to-top').fadeIn(duration);
    } else{
      $('.back-to-top').fadeOut(duration);
    }
  });

  $('.back-to-top').click(function(event){
    event.preventDefault();
    $('html, body').animate({scrollTop: 0}, duration);
    return false;
  });
}

var onceTabsNavigation = function(){
  if($("[data-tabs='enable']").length > 0){
    $("[data-tabs='enable'] li").click(function(e){
      var $this = $(this),
          tabSliderW = $this.width(),
          tabSliderX = $this.position();

      if($this.hasClass('tab-slider')){
        return;
      }

      $this.siblings(".tab-slider").css({
        left: tabSliderX.left + "px",
        width: tabSliderW + "px"
      });

      if($this.parents(".nav-tabs[data-ripple]")){
        $(".ripple").remove();

        var posX = $this.offset().left,
            posY = $this.offset().top,
            buttonWidth = $this.width(),
            buttonHeight = $this.height();

        $this.prepend("<span class='ripple'></span>");

        if (buttonWidth >= buttonHeight){
          buttonHeight = buttonWidth;
        } else{
          buttonWidth = buttonHeight;
        }

        var x = e.pageX - posX - buttonWidth / 2;
        var y = e.pageY - posY - buttonHeight / 2;

        $(".ripple").css({
          width: buttonWidth,
          height: buttonHeight,
          top: y + 'px',
          left: x + 'px'
        }).addClass("rippleEffect");
      }
    });

    $("[data-tabs='enable'] li:first-child").trigger("click");
  }
}

var onceCollapse = function(){
  $('[data-toggle="collapse"]').click(function(e){
    if($(this).data("ripple")){
      $(".ripple").remove();

      var posX = $(this).offset().left,
          posY = $(this).offset().top,
          buttonWidth = $(this).width(),
          buttonHeight = $(this).height();

      $(this).prepend("<span class='ripple'></span>");

      if (buttonWidth >= buttonHeight){
        buttonHeight = buttonWidth;
      } else{
        buttonWidth = buttonHeight;
      }

      var x = e.pageX - posX - buttonWidth / 2;
      var y = e.pageY - posY - buttonHeight / 2;

      $(".ripple").css({
        width: buttonWidth,
        height: buttonHeight,
        top: y + 'px',
        left: x + 'px'
      }).addClass("rippleEffect");
    }
  });
}

var onceSelectPicker = function(){
  if($('.selectpicker').length > 0){
    $('.selectpicker').selectpicker({
      iconBase: "icon",
      tickIcon: "icon-done"
    });
  }
}

var onceCreatePassword = function(){
  if($('#inputPassword-2').length > 0){
    $("#inputPassword-2").keyup(function() {
      passwordStrength($(this).val());
    });
  }
}

var onceDatePicker = function(){
  if($('#datepicker').length > 0){
    $('#datepicker').datetimepicker({
      locale: 'en',
      format: 'L',
      icons: {
        up: "icon icon-arrow-up",
        down: "icon icon-arrow-down",
        next: "icon icon-arrow-right",
        previous: "icon icon-arrow-left"
      }
    });
  }
}

var onceSearchbox = function(){
  if($('#autocomplete').length > 0){
    var countriesArray = $.map({"AD": "Andorra", "A2": "Andorra Test", "AE": "United Arab Emirates", "AF": "Afghanistan", "AG": "Antigua and Barbuda", "AI": "Anguilla", "AL": "Albania", "AM": "Armenia", "AN": "Netherlands Antilles", "AO": "Angola", "AQ": "Antarctica", "AR": "Argentina", "AS": "American Samoa", "AT": "Austria", "AU": "Australia", "AW": "Aruba", "AX": "\u00c5land Islands", "AZ": "Azerbaijan", "BA": "Bosnia and Herzegovina", "BB": "Barbados", "BD": "Bangladesh", "BE": "Belgium", "BF": "Burkina Faso", "BG": "Bulgaria", "BH": "Bahrain", "BI": "Burundi", "BJ": "Benin", "BL": "Saint Barth\u00e9lemy", "BM": "Bermuda", "BN": "Brunei", "BO": "Bolivia", "BQ": "British Antarctic Territory", "BR": "Brazil", "BS": "Bahamas", "BT": "Bhutan", "BV": "Bouvet Island", "BW": "Botswana", "BY": "Belarus", "BZ": "Belize", "CA": "Canada", "CC": "Cocos [Keeling] Islands", "CD": "Congo - Kinshasa", "CF": "Central African Republic", "CG": "Congo - Brazzaville", "CH": "Switzerland", "CI": "C\u00f4te d\u2019Ivoire", "CK": "Cook Islands", "CL": "Chile", "CM": "Cameroon", "CN": "China", "CO": "Colombia", "CR": "Costa Rica", "CS": "Serbia and Montenegro", "CT": "Canton and Enderbury Islands", "CU": "Cuba", "CV": "Cape Verde", "CX": "Christmas Island", "CY": "Cyprus", "CZ": "Czech Republic", "DD": "East Germany", "DE": "Germany", "DJ": "Djibouti", "DK": "Denmark", "DM": "Dominica", "DO": "Dominican Republic", "DZ": "Algeria", "EC": "Ecuador", "EE": "Estonia", "EG": "Egypt", "EH": "Western Sahara", "ER": "Eritrea", "ES": "Spain", "ET": "Ethiopia", "FI": "Finland", "FJ": "Fiji", "FK": "Falkland Islands", "FM": "Micronesia", "FO": "Faroe Islands", "FQ": "French Southern and Antarctic Territories", "FR": "France", "FX": "Metropolitan France", "GA": "Gabon", "GB": "United Kingdom", "GD": "Grenada", "GE": "Georgia", "GF": "French Guiana", "GG": "Guernsey", "GH": "Ghana", "GI": "Gibraltar", "GL": "Greenland", "GM": "Gambia", "GN": "Guinea", "GP": "Guadeloupe", "GQ": "Equatorial Guinea", "GR": "Greece", "GS": "South Georgia and the South Sandwich Islands", "GT": "Guatemala", "GU": "Guam", "GW": "Guinea-Bissau", "GY": "Guyana", "HK": "Hong Kong SAR China", "HM": "Heard Island and McDonald Islands", "HN": "Honduras", "HR": "Croatia", "HT": "Haiti", "HU": "Hungary", "ID": "Indonesia", "IE": "Ireland", "IL": "Israel", "IM": "Isle of Man", "IN": "India", "IO": "British Indian Ocean Territory", "IQ": "Iraq", "IR": "Iran", "IS": "Iceland", "IT": "Italy", "JE": "Jersey", "JM": "Jamaica", "JO": "Jordan", "JP": "Japan", "JT": "Johnston Island", "KE": "Kenya", "KG": "Kyrgyzstan", "KH": "Cambodia", "KI": "Kiribati", "KM": "Comoros", "KN": "Saint Kitts and Nevis", "KP": "North Korea", "KR": "South Korea", "KW": "Kuwait", "KY": "Cayman Islands", "KZ": "Kazakhstan", "LA": "Laos", "LB": "Lebanon", "LC": "Saint Lucia", "LI": "Liechtenstein", "LK": "Sri Lanka", "LR": "Liberia", "LS": "Lesotho", "LT": "Lithuania", "LU": "Luxembourg", "LV": "Latvia", "LY": "Libya", "MA": "Morocco", "MC": "Monaco", "MD": "Moldova", "ME": "Montenegro", "MF": "Saint Martin", "MG": "Madagascar", "MH": "Marshall Islands", "MI": "Midway Islands", "MK": "Macedonia", "ML": "Mali", "MM": "Myanmar [Burma]", "MN": "Mongolia", "MO": "Macau SAR China", "MP": "Northern Mariana Islands", "MQ": "Martinique", "MR": "Mauritania", "MS": "Montserrat", "MT": "Malta", "MU": "Mauritius", "MV": "Maldives", "MW": "Malawi", "MX": "Mexico", "MY": "Malaysia", "MZ": "Mozambique", "NA": "Namibia", "NC": "New Caledonia", "NE": "Niger", "NF": "Norfolk Island", "NG": "Nigeria", "NI": "Nicaragua", "NL": "Netherlands", "NO": "Norway", "NP": "Nepal", "NQ": "Dronning Maud Land", "NR": "Nauru", "NT": "Neutral Zone", "NU": "Niue", "NZ": "New Zealand", "OM": "Oman", "PA": "Panama", "PC": "Pacific Islands Trust Territory", "PE": "Peru", "PF": "French Polynesia", "PG": "Papua New Guinea", "PH": "Philippines", "PK": "Pakistan", "PL": "Poland", "PM": "Saint Pierre and Miquelon", "PN": "Pitcairn Islands", "PR": "Puerto Rico", "PS": "Palestinian Territories", "PT": "Portugal", "PU": "U.S. Miscellaneous Pacific Islands", "PW": "Palau", "PY": "Paraguay", "PZ": "Panama Canal Zone", "QA": "Qatar", "RE": "R\u00e9union", "RO": "Romania", "RS": "Serbia", "RU": "Russia", "RW": "Rwanda", "SA": "Saudi Arabia", "SB": "Solomon Islands", "SC": "Seychelles", "SD": "Sudan", "SE": "Sweden", "SG": "Singapore", "SH": "Saint Helena", "SI": "Slovenia", "SJ": "Svalbard and Jan Mayen", "SK": "Slovakia", "SL": "Sierra Leone", "SM": "San Marino", "SN": "Senegal", "SO": "Somalia", "SR": "Suriname", "ST": "S\u00e3o Tom\u00e9 and Pr\u00edncipe", "SU": "Union of Soviet Socialist Republics", "SV": "El Salvador", "SY": "Syria", "SZ": "Swaziland", "TC": "Turks and Caicos Islands", "TD": "Chad", "TF": "French Southern Territories", "TG": "Togo", "TH": "Thailand", "TJ": "Tajikistan", "TK": "Tokelau", "TL": "Timor-Leste", "TM": "Turkmenistan", "TN": "Tunisia", "TO": "Tonga", "TR": "Turkey", "TT": "Trinidad and Tobago", "TV": "Tuvalu", "TW": "Taiwan", "TZ": "Tanzania", "UA": "Ukraine", "UG": "Uganda", "UM": "U.S. Minor Outlying Islands", "US": "United States", "UY": "Uruguay", "UZ": "Uzbekistan", "VA": "Vatican City", "VC": "Saint Vincent and the Grenadines", "VD": "North Vietnam", "VE": "Venezuela", "VG": "British Virgin Islands", "VI": "U.S. Virgin Islands", "VN": "Vietnam", "VU": "Vanuatu", "WF": "Wallis and Futuna", "WK": "Wake Island", "WS": "Samoa", "YD": "People's Democratic Republic of Yemen", "YE": "Yemen", "YT": "Mayotte", "ZA": "South Africa", "ZM": "Zambia", "ZW": "Zimbabwe", "ZZ": "Unknown or Invalid Region"}, function (value, key) { return { value: value, data: key }; });

    $('#autocomplete').devbridgeAutocomplete({
      lookup: countriesArray,
      minChars: 3,
      onSelect: function (suggestion) {
          $('#selection').html('You selected: ' + suggestion.value + ', ' + suggestion.data.category);
      },
      showNoSuggestionNotice: true,
      noSuggestionNotice: 'Sorry, no matching results'
    });
  }
}
