# ONCE, the new Design System for BNPP is now available.

ONCE is a Design System initiated by CIB's UX team and available since the 7th of November 2018. Its purpose is to promote and accelerate design decisions.

<a href="https://once.cib.echonet" target="_blank">Visit ONCE's website here</a>

__ONCE is open to everyone and we want everyone to be able to contribute to ONCE.__

## What is a Design System?

It is a series of guidelines and components that can be reused in different combinations to manage the design to scale. It's a bit like a LEGO.

## Getting started

Download the files from the <a href="https://once.cib.echonet/downloads.html" target="_blank">site</a>.

## How to contribute?

Because we want ONCE to be a living visual language, we want you to collaborate with us to make it even more complete and exciting. You can:
- suggest a new component
- design a new component
- code a new component
- develop an existing component on a new language

So get on board and come and participate. The Design System is a living language built and carried by the community...
